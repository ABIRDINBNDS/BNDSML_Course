# Author: Zheng Zijie

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from sklearn import neighbors, datasets
from sklearn.metrics import classification_report

n_neighbors = 15

def load_datafromexcel(path): 
    #统一格式为：第0行为header行，第0列为index列，最后一列是label
    Sample_excel = pd.read_csv(path, header = 0, index_col = 0)
    Sample = Sample_excel.values  #转成numpy数组
    y = Sample[:,Sample.shape[1]-1]
    #print(y)
    X = Sample[:,0:Sample.shape[1]-1]
    #print(X)
    return X,y

def draw_figure(X,y,clf): #画图函数，画mesh图片
    h = .02  # mesh图片的网格精度为0.02
    # 定义一个mesh图片的基本参数
    cmap_light = ListedColormap(['orange', 'cyan', 'cornflowerblue'])
    cmap_bold = ListedColormap(['darkorange', 'c', 'darkblue'])
    # 画mesh图片
    x_min, x_max = X[:, 0].min() - 1, X[:, 0].max() + 1
    y_min, y_max = X[:, 1].min() - 1, X[:, 1].max() + 1
    xx, yy = np.meshgrid(np.arange(x_min, x_max, h), np.arange(y_min, y_max, h))
    y_predict=clf.predict(np.c_[xx.ravel(), yy.ravel()])    
    # 
    y_predict = y_predict.reshape(xx.shape)
    plt.figure(1) #画原来的数据点
    plt.scatter(X[:, 0], X[:, 1], c=y, cmap=cmap_bold, edgecolor='k', s=20)
    
    plt.figure(2) #画分割模型
    plt.pcolormesh(xx, yy, y_predict, cmap=cmap_light)
    plt.scatter(X[:, 0], X[:, 1], c=y, cmap=cmap_bold, edgecolor='k', s=20)
    plt.xlim(xx.min(), xx.max())
    plt.ylim(yy.min(), yy.max())
    plt.xlabel("Sepal.Length")
    plt.ylabel("Sepal.Width")
    plt.title("KNN, Iris")   
    return

if __name__ == '__main__':
    X_train, y_train = load_datafromexcel(path = 'iris_train.csv')  #读取训练集数据
    X_train = X_train[:,:2] #选择前两个feature训练模型，使得可以可视化(画在平面图形上)
    X_test, y_test =  load_datafromexcel(path = 'iris_test.csv') #读取测试集
    X_test = X_test[:,:2] #选择前两个feature测试模型模型，使得可以可视化（画在平面图形上）
    #训练模型
    n_neighbors = 15
    clf =  neighbors.KNeighborsClassifier(n_neighbors) #使用KNN
    clf.fit(X_train,y_train) #不管算法怎么执行的，直接进行模型建立
    
    # training set的拟合准确率
    y_predict_train = clf.predict(X_train)
    print(classification_report(y_train,y_predict_train))
    
    # testing set的拟合准确率
    y_predict_test = clf.predict(X_test)
    print(classification_report(y_test,y_predict_test))
    
    #draw_figure(X_train,y_train,clf) #画图
    draw_figure(X_test,y_test,clf) #画图看测试集的点






