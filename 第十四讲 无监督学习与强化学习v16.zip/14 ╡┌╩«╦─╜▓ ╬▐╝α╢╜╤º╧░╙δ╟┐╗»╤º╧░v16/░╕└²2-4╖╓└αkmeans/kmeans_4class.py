# -*- coding: utf-8 -*-
"""
Created on Sat Aug 15 20:14:54 2020

@author: zzj
"""


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn import metrics
from sklearn.cluster import KMeans

def load_datafromexcel(path): 
    #统一格式为：第0行为header行，第0列为index列，没有label
    Sample_excel = pd.read_excel(path, header = 0, index_col = 0)
    Sample = Sample_excel.values  #转成numpy数组
    X = Sample[:,0:Sample.shape[1]]
    return X

if __name__ == '__main__':
    X = load_datafromexcel(path = '4class.xlsx')  #读取训练集数据
    plt.figure(1)
    plt.plot(X[:, 0], X[:, 1],'*')
    ###分成四类
    plt.figure(2)
    clf = KMeans(n_clusters = 4).fit(X)
    y_predict = clf.predict(X)  #预测归的类
    for i in range(len(y_predict)):
        if y_predict[i] == 0:
            plt.plot(X[i, 0], X[i, 1],'*r')
        elif y_predict[i] == 1:
            plt.plot(X[i, 0], X[i, 1],'*b')
        elif y_predict[i] == 2:
            plt.plot(X[i, 0], X[i, 1],'*g')
        else: 
            plt.plot(X[i, 0], X[i, 1],'*m')
    print(clf.cluster_centers_)
    plt.plot(clf.cluster_centers_[:,0],clf.cluster_centers_[:,1],'^k')
    plt.title("4 class Kmeans")
    
    ###分成两类
    # plt.figure(3)
    # clf2 = KMeans(n_clusters =2).fit(X)
    # y_predict2 = clf2.predict(X)  #预测归的类
    # for i in range(len(y_predict2)):
    #     if y_predict2[i] == 0:
    #         plt.plot(X[i, 0], X[i, 1],'*r')
    #     else: 
    #         plt.plot(X[i, 0], X[i, 1],'*b')
    # print(clf2.cluster_centers_)
    # plt.plot(clf2.cluster_centers_[:,0],clf2.cluster_centers_[:,1],'^k')
    # plt.title("2 class K-means")
        
    
