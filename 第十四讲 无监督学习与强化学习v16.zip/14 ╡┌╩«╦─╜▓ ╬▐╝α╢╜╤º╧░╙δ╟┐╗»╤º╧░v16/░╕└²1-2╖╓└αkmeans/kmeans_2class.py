# -*- coding: utf-8 -*-
"""
Created on Sat Aug 15 20:14:54 2020

@author: zzj
"""


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn import metrics
from sklearn.cluster import KMeans

def load_datafromexcel(path): 
    #统一格式为：第0行为header行，第0列为index列，没有label
    Sample_excel = pd.read_excel(path, header = 0, index_col = 0)
    Sample = Sample_excel.values  #转成numpy数组
    X = Sample[:,0:Sample.shape[1]]
    return X

if __name__ == '__main__':
    X = load_datafromexcel(path = '2class.xlsx')  #读取训练集数据
    plt.figure(1)
    plt.plot(X[:, 0], X[:, 1],'*')
    plt.figure(2)
    plt.plot(X[0:20, 0], X[0:20, 1],'*g')
    plt.plot(X[21:40, 0], X[21:40, 1],'^k')