# -*- coding: utf-8 -*-
"""
Created on Mon Aug 10 16:44:35 2020

Kidge Regression（岭回归，新冠疫情）

author: zzj
"""
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.linear_model import Ridge
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import PolynomialFeatures


def lagrangian_interplot(x_sample, y_sample, x):
    y = np.zeros(len(x))
    for n in range(len(y)):
        for i in range(len(x_sample)):
            y_addtemp = y_sample[i]
            for j in range(len(x_sample)):
                if j != i:
                    y_addtemp = y_addtemp * (x[n]-x_sample[j])/(x_sample[i]-x_sample[j])
            y[n] = y[n] + y_addtemp
    return y  

if __name__ == "__main__":
    data=pd.read_csv("data_covid19mar.csv") #读取covid193月分的数据
    #print(data)
    x_sample = data['Mar']
    y_sample = data['Num_of_cases'] 
    x_sample = np.array(x_sample).reshape(-1,1) #sklearn 要求所有的feature都是二维数组，遇到这种问题直接百度    

    #----原始数据-------#
    plt.figure(1)
    plt.title('Original Data')
    plt.plot(x_sample,y_sample,'*')
    plt.xlabel(u"Mar")
    plt.ylabel(u"No. of Cases") 
    
    #---拉格朗日插值公式---任意次多项式插值# 
    plt.figure(2) 
    plt.title('Lagrange Interpolation Formula')
    plt.plot(x_sample,y_sample,'*')
    plt.xlabel(u"Mar")
    plt.ylabel(u"No. of Cases")
    #plt.ylim(-10,1000)
    x = np.arange(16,31.1,0.1)
    y_lagrangian = lagrangian_interplot(x_sample,y_sample,x)
    plt.plot(x,y_lagrangian)
    
    #---线性回归-------#
    clf_linear = Ridge(alpha=1e-6)
    clf_linear.fit(x_sample,y_sample)
    #-----function a+bx-----#
    a = clf_linear.intercept_  #----截距
    print(a)
    b = clf_linear.coef_  #----斜率
    print(b)
    
    plt.figure(3)
    plt.title('Linear Regression')
    plt.plot(x_sample,y_sample,'*')
    x = np.arange(16,31.1,0.1)
    x = x.reshape(-1,1)
    y_linear = clf_linear.predict(x)
    plt.plot(x,y_linear)    
    plt.xlabel(u"Mar")
    plt.ylabel(u"No. of Cases")

    #---二次函数回归-------#
    poly_reg  = PolynomialFeatures(degree=2)  #多项式回归得算法直接调用
    x_poly = poly_reg.fit_transform(x_sample)
    #print(x_poly)
    clf_poly2 = Ridge(alpha = 0.01)
    clf_poly2.fit(x_poly,y_sample)    
    
    plt.figure(4)
    plt.title('Quadratic Regression')
    plt.plot(x_sample,y_sample,'*')
    x = np.arange(16,31.1,0.1)
    x = x.reshape(-1,1)
    y_poly2 = clf_poly2.predict(poly_reg.fit_transform(x))
    plt.plot(x,y_poly2)
    plt.xlabel(u"Mar")
    plt.ylabel(u"No. of Cases")
    
    
    #---10次函数回归--通过正则化系数选择-----#
    poly_reg  = PolynomialFeatures(degree=10) 
    x_poly = poly_reg.fit_transform(x_sample)
    #print(x_poly)
    clf_poly2 = Ridge(alpha = 5)
    clf_poly2.fit(x_poly,y_sample)    
    
    plt.figure(5)
    plt.title('10-order Polynomial Rregression')
    plt.plot(x_sample,y_sample,'*')
    x = np.arange(16,31.1,0.1)
    x = x.reshape(-1,1)
    y_poly2 = clf_poly2.predict(poly_reg.fit_transform(x))
    plt.plot(x,y_poly2)
    plt.xlabel(u"Mar")
    plt.ylabel(u"No. of Cases")

    

    