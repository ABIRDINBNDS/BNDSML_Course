# -*- coding: utf-8 -*-
"""
Created on Thu Aug  5 20:48:35 2021

@author: NING MEI
"""


import cv2
import matplotlib.pyplot as plt
import numpy as np
from scipy import signal

dirpath = "tsinghua.jpg" #读取图片
img_cv   = cv2.imread(dirpath) 
plt.figure(0) #画出原始图片
plt.imshow(img_cv) #画出原始图片
img_cv0  = img_cv[:,:,0] 
plt.figure(1)
plt.imshow(img_cv0, cmap=plt.cm.binary) #打印灰度图
filter_2=np.array([[1,0,-1]]) #提取纵向边界
der_2=signal.convolve2d(img_cv0,filter_2,mode='same') #scipy中的signal自带卷积运算
plt.figure(2)
plt.imshow(der_2, cmap=plt.cm.binary) #打印灰度图

filter_3=filter_2.T #提取横向边界
der_3=signal.convolve2d(img_cv0,filter_3,mode='same')
plt.figure(3)
plt.imshow(der_3, cmap=plt.cm.binary) #打印灰度图


filter_4=np.array([[1/9,1/9,1/9],
                   [1/9,1/9,1/9],
                   [1/9,1/9,1/9]]) #模糊
der_4=signal.convolve2d(img_cv0,filter_4,mode='same')
plt.figure(4)
plt.imshow(der_4, cmap=plt.cm.binary) #打印灰度图

filter_5=np.array([[0,0,0],
                   [0,2,0],
                   [0,0,0]])-filter_4 #锐化
der_5=signal.convolve2d(img_cv0,filter_5,mode='same') 
plt.figure(5)
plt.imshow(der_5, cmap=plt.cm.binary) #打印灰度图