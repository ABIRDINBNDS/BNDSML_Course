# -*- coding: utf-8 -*-
"""
Created on Tue Aug 11 20:12:48 2020

@author: zzj
"""


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import axes3d
from matplotlib.colors import ListedColormap
from matplotlib import cm
from sklearn import datasets
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import classification_report




def load_datafromexcel(path): 
    #统一格式为：第0行为header行，第0列为index列，最后一列是label
    Sample_excel = pd.read_csv(path, header = 0, index_col = 0)
    Sample = Sample_excel.values  #转成numpy数组
    y = Sample[:,Sample.shape[1]-1]
    #print(y)
    X = Sample[:,0:Sample.shape[1]-1]
    #print(X)
    return X,y

def draw_figure(X,y,clf): #画图函数
    h = .02  # step size in the mesh
    # Create color maps
    cmap_light = ListedColormap(['orange', 'cyan', 'cornflowerblue'])
    cmap_bold = ListedColormap(['darkorange', 'c', 'darkblue'])
    # Draw mesh
    x_min, x_max = X[:, 0].min() - 1, X[:, 0].max() + 1
    y_min, y_max = X[:, 1].min() - 1, X[:, 1].max() + 1
    xx, yy = np.meshgrid(np.arange(x_min, x_max, h), np.arange(y_min, y_max, h))
    y_predict=clf.predict(np.c_[xx.ravel(), yy.ravel()])    
    #Put the result into a color plot
    y_predict = y_predict.reshape(xx.shape)
    plt.figure()
    plt.pcolormesh(xx, yy, y_predict, cmap=cmap_light)
    # Plot also the training points
    plt.scatter(X[:, 0], X[:, 1], c=y, cmap=cmap_bold, edgecolor='k', s=20)
    plt.xlim(xx.min(), xx.max())
    plt.ylim(yy.min(), yy.max())
    plt.title("Nerual Network, Iris 2 feature 2 label")   
    return

def draw_mesh(X,y,clf): #画三维图
    h = .02  # step size in the mesh
    x_min, x_max = X[:, 0].min() - 1, X[:, 0].max() + 1
    y_min, y_max = X[:, 1].min() - 1, X[:, 1].max() + 1
    xx, yy = np.meshgrid(np.arange(x_min, x_max, h), np.arange(y_min, y_max, h))
    y_predict=clf.predict(np.c_[xx.ravel(), yy.ravel()]) 
    y_predict = y_predict.reshape(xx.shape)
    ax = plt.figure().add_subplot(projection='3d')
    ax.plot_surface(xx, yy, y_predict, rstride=10, cstride=10, alpha=0.3)    
    return

if __name__ == '__main__':
    #读取训练集数据
    X_train, y_train = load_datafromexcel(path = 'iris_2feature2label_train.csv')  
    X_train = X_train[:,:2]
    #读取测试集
    X_test, y_test = load_datafromexcel(path = 'iris_2feature2label_test.csv')  
    X_test = X_test[:,:2]
    #训练模型,含有一个隐含层、神经元个数为5的神经网络模型
    clf =  MLPClassifier(solver='lbfgs', alpha=1e-5, hidden_layer_sizes=(5), random_state=1) 
    clf.fit(X_train,y_train) #不管算法怎么执行的，直接进行模型建立
    
    # training set的拟合准确率
    y_predict_train = clf.predict(X_train)
    print(classification_report(y_train,y_predict_train))
    
    # testing set的拟合准确率
    y_predict_test = clf.predict(X_test)
    print(classification_report(y_test,y_predict_test))
    
    
    draw_figure(X_train,y_train,clf) #使用训练集集进行画图验证
    draw_figure(X_test,y_test,clf) #使用测试集进行画图验证
    draw_mesh(X_train,y_train,clf) #画mesh图
    

    
