# -*- coding: utf-8 -*-
"""
Created on Wed Jan 19 15:51:02 2022

@author: 郑子杰
"""

import os
import struct
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd



if __name__ == '__main__':   
    plt.figure(1)
    x1 = 0.01*np.linspace(-700,700)
    y1 = 1/(1+np.exp(-x1))
    plt.grid()
    plt.xlabel('x')
    plt.ylabel('y')
    plt.plot(x1,y1,'-')
    
    plt.figure(2)
    x2 = 0.01*np.linspace(-700,700)
    y2 = (np.exp(x2)-np.exp(-x2))/(np.exp(x2)+np.exp(-x2))
    plt.grid()
    plt.xlabel('x')
    plt.ylabel('y')
    plt.plot(x2,y2,'-g')
    
    
    plt.figure(3)
    x3 = 0.01*np.linspace(-700,700)
    y3 = x3*(x3>0)+0*(x3<=0)
    plt.grid()
    plt.xlabel('x')
    plt.ylabel('y')
    plt.plot(x3,y3,'-k')
   
     





