# -*- coding: utf-8 -*-
"""
Created on Tue Aug 11 20:55:07 2020

@author：Zheng Zijie
"""


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt 
from mpl_toolkits.mplot3d import Axes3D

plt.figure(1)
x = np.arange(-5,5,0.01)
y = x*x+2*x
plt.plot(x,y)
plt.xlabel('x')
plt.ylabel('y')

plt.figure(2)
x = np.arange(-2,0,0.01)
y = x*x+2*x
plt.plot(x,y)
plt.xlabel('x')
plt.ylabel('y')

plt.figure(3)
x = np.arange(-5,5,0.01)
y = abs(x)
plt.plot(x,y)
plt.xlabel('x')
plt.ylabel('y')

fig4 = plt.figure(4)
a = np.arange(-3,5,0.01)
b = np.arange(-3,5,0.01)
A,B = np.meshgrid(a,b)
x1 = 0
y1 = 1
x2 = 1
y2 = 2
los = (A+B*x1-y1)**2+(A+B*x2-y2)**2
ax = Axes3D(fig4)
ax.plot_surface(A, B, los, alpha= 0.8,cmap= 'rainbow')
ax.contour(A,B,los,zdir= 'z', offset=0,cmap= "rainbow") #生成z方向投影，投到x-y平面