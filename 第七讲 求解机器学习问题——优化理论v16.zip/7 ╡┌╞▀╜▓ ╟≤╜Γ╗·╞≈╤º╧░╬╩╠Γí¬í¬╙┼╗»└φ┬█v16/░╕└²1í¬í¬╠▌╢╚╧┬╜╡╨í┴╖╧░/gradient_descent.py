# -*- coding: utf-8 -*-

#author: Zheng Zijie

#Gradient Descent Method for y= x^4+2x

import numpy as np
import matplotlib.pyplot as plt

x_i = 10
x_j = 9
x_mem = [x_i,x_j]
y_mem = [pow(x_i,4)+2*x_i,pow(x_j,4)+2*x_j]
alpha = 0.0005 #如果这里alpha选择不恰当就会产生震荡
while abs(x_i*x_i*x_i*x_i+2*x_i-x_j*x_j*x_j*x_j-2*x_j)>0.001: #梯度下降开始，停止条件 gredient decent
    delta = -(4*(x_j*x_j*x_j)+2)  #梯度值（导数值、差分值）
    x_temp = x_j+alpha*delta
    x_i = x_j
    x_j = x_temp
    y_temp = pow(x_temp,4)+2*x_temp
    x_mem.append(x_temp)
    y_mem.append(y_temp)
print(x_mem)

x_curve = np.arange(-10, 11, 0.01)
y_curve = pow(x_curve,4)+2*x_curve
plt.figure(1)
plt.plot(x_curve,y_curve,'k-')
plt.plot(x_mem,y_mem,'b*-')
plt.title('y=x^4+2x')